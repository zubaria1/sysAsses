import { StyleSheet, Text } from "react-native";

import React from "react";

const UniversityDetailScreen = ({ item }) => {
  return (
    <Text>nfrjr</Text>
  );
};

const styles = StyleSheet.create({
});

export default UniversityDetailScreen;
